"""Serialization and deserialization functions for Prosemirror documents."""

from typing import cast

from prosemirror import Schema
from prosemirror.model import DOMSerializer, Node
from prosemirror.model.from_dom import from_html

from django_prosemirror.constants import get_empty_doc
from django_prosemirror.schema import ProsemirrorDocumentDict


class _VisibleContentFound(Exception):
    """Raised by `_node_has_visible_content` to abort traversal early."""


def _node_has_visible_content(node: Node) -> bool:
    """
    Return True if a parsed Prosemirror node has visible content.

    A node is considered visually empty when it has no text anywhere and no
    atom/leaf descendants (e.g. images, horizontal rules) — i.e. it consists only
    of empty block containers like a lone empty paragraph, which an editor cannot
    avoid emitting once all text is deleted (schemas require `doc: "block+"`).
    """
    if node.text_content.strip():
        return True

    def check(child: Node, pos: int, parent: Node | None, index: int) -> None:
        if (child.is_leaf or child.is_atom) and not child.is_text:
            raise _VisibleContentFound

    try:
        node.descendants(check)
    except _VisibleContentFound:
        return True

    return False


def is_doc_empty(value: ProsemirrorDocumentDict | None, *, schema: Schema) -> bool:
    """Return True if the Prosemirror document has no visible content."""
    if not value or not value.get("content"):
        return True

    return not _node_has_visible_content(Node.from_json(schema, value))


def _clean_empty_attrs(
    doc: ProsemirrorDocumentDict, schema: Schema
) -> ProsemirrorDocumentDict:
    """Remove empty attrs from marks that don't have attributes defined in the schema.

    The prosemirror library automatically adds empty attrs: {} to all marks during
    HTML parsing, even when the mark specification doesn't define any attributes.
    This function cleans those up to match the expected document structure.

    Also removes marks from text nodes inside nodes that don't allow marks (like code_
    block). Additionally, removes node attributes that match their default values.
    """

    def clean_node(node: dict, parent_node_type=None) -> dict:
        if not isinstance(node, dict):
            raise ValueError(f"{node} is not a dict")

        node_type = node.get("type")

        # Check if current node type disallows marks
        parent_disallows_marks = False
        if parent_node_type:
            parent_node_spec = schema.nodes.get(parent_node_type)
            if parent_node_spec and parent_node_spec.spec.get("marks") == "":
                parent_disallows_marks = True

        # Clean up image node attributes that match default values
        if node_type == "filer_image" and "attrs" in node:
            node_spec = schema.nodes.get(node_type)
            if node_spec and hasattr(node_spec, "spec") and "attrs" in node_spec.spec:
                cleaned_attrs = {}
                for attr_name, attr_value in node["attrs"].items():
                    attr_spec = node_spec.spec["attrs"].get(attr_name, {})
                    default_value = attr_spec.get("default")
                    # Keep attribute only if it doesn't match the default value
                    if attr_value != default_value:
                        cleaned_attrs[attr_name] = attr_value

                # Update node with cleaned attrs, or remove attrs entirely if empty
                if cleaned_attrs:
                    node = {**node, "attrs": cleaned_attrs}
                else:
                    node = {k: v for k, v in node.items() if k != "attrs"}

        # Clean up marks in text nodes
        if node_type == "text" and "marks" in node:
            if parent_disallows_marks:
                # Remove all marks if parent node doesn't allow marks
                node = {k: v for k, v in node.items() if k != "marks"}
            else:
                # Clean empty attrs from marks
                cleaned_marks = []
                for mark in node["marks"]:
                    if isinstance(mark, dict) and "type" in mark:
                        mark_type = schema.marks.get(mark["type"])
                        # If mark has empty attrs and the mark type doesn't define attrs
                        # remove attrs
                        if (
                            mark_type
                            and mark.get("attrs") == {}
                            and (
                                not hasattr(mark_type, "attrs")
                                or (hasattr(mark_type, "attrs") and not mark_type.attrs)
                            )
                        ):
                            cleaned_mark = {
                                k: v for k, v in mark.items() if k != "attrs"
                            }
                            cleaned_marks.append(cleaned_mark)
                        else:
                            cleaned_marks.append(mark)
                    else:
                        cleaned_marks.append(mark)
                node = {**node, "marks": cleaned_marks}

        # Recursively clean content, passing current node type as parent
        if "content" in node:
            node = {
                **node,
                "content": [clean_node(child, node_type) for child in node["content"]],
            }

        return node

    return clean_node(cast(dict, doc))


def doc_to_html(value: ProsemirrorDocumentDict | None, *, schema: Schema) -> str:
    """Convert a Prosemirror document to HTML.

    Args:
        value: object containing the Prosemirror document (must be dict or None)
        schema: Prosemirror schema defining document structure

    Returns:
        str: HTML representation of the document

    Raises:
        ValueError: If value is not a dict or None

    Note:
        We require dict specifically (not Mapping) because all documents come from
        Django's JSONField which always produces dict objects.
    """
    # Handle None/empty values
    if value is None:
        return ""

    # Validate that value is a dict (required by Django field API constraints)
    if not isinstance(value, dict):
        raise ValueError(
            f"Prosemirror document must be a dict, got {type(value).__name__}"
        )

    # Empty dict should also return empty string
    if not value:
        return ""

    content = Node.from_json(schema, value)
    if not _node_has_visible_content(content):
        return ""

    serializer = DOMSerializer.from_schema(schema)
    return str(serializer.serialize_fragment(content))


def html_to_doc(value: str, *, schema: Schema) -> ProsemirrorDocumentDict:
    """Convert HTML to a Prosemirror document.

    Args:
        value: HTML string to convert
        schema: Prosemirror schema defining document structure

    Returns:
        ProsemirrorDocumentDict: Document as dict structure
    """
    if not value.strip():
        # Return empty document for empty/whitespace-only strings
        return get_empty_doc()

    doc = from_html(schema, value)
    # from_html returns JSONDict (Mapping), but we know it's actually a dict
    # Validate and cast to ensure type safety
    if not isinstance(doc, dict):
        raise ValueError(f"Expected from_html to return dict, got {type(doc).__name__}")
    return _clean_empty_attrs(doc, schema)
